# animal-farm-priority1-3-1117-3

22 PNG 파일이 포함되어 있습니다. 파일명·크기·프레임·배치 앵커는 asset-map.json에 기록했습니다. 모든 PNG는 전체 팩과 동일합니다.

전체 설명·미리보기: https://github.com/Seain17/Winedb/tree/codex/animal-farm-resources-1117-3/deliveries/animal-farm-1117-3

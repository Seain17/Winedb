from pathlib import Path
from PIL import Image, ImageChops
import json,hashlib,zipfile,html
R=Path(__file__).resolve().parent.parent
spec={'S-PRODUCT':(256,5,1),'S-WORK':(512,5,1),'S-WALK':(512,3,5),'S-HOME':(512,5,1),'S-FOOD':(256,6,1),'S-EAT':(512,5,1),'S-EMOTE':(128,8,1),'S-ARRIVE':(512,5,1),'S-ARRIVE_2':(1024,1,1),'S-LOCKED':(256,5,1),'S-COIN2':(128,3,1),'S-FX2':(256,6,1),'S-WIDGET-ANI':(512,3,5)}
orders={'S-PRODUCT':['apple','yuzu','wool','acorn','bamboo-shoot'],'S-FOOD':['apple-berries','yuzu-watermelon','clover-hay','acorn-sunflower','bamboo-shoot','special-snack'],'S-EMOTE':['heart','music','exclamation','question','sleep-cloud','sparkle','empty-bowl','full-basket'],'S-COIN2':['single','three','basket'],'S-FX2':['dust','water','wool','leaves','bamboo-leaves','falling-apple']}
manifest=[];checks=[]
for id,(s,cols,rows) in spec.items():
 p=R/'sheets'/f'{id}.png';im=Image.open(p).convert('RGBA');assert im.size==(s*cols,s*rows),(id,im.size)
 cells=[]
 for n in range(cols*rows):
  x=n%cols*s;y=n//cols*s;alpha=im.crop((x,y,x+s,y+s)).getchannel('A');bb=alpha.point(lambda a:255 if a>=24 else 0).getbbox();assert bb,(id,n,'empty')
  margin=min(bb[0],bb[1],s-bb[2],s-bb[3]);assert margin>=s*.08,(id,n,bb,margin)
  if rows==5: name=f'A{n//3+1}_f{n%3+1}'
  else:name=orders.get(id,[f'A{i+1}' for i in range(cols)])[n]
  cells.append(dict(id=name,x=x,y=y,width=s,height=s,visible_bbox=bb))
 manifest.append(dict(id=id,file=f'sheets/{id}.png',width=im.width,height=im.height,columns=cols,rows=rows,cell_size=s,transparent=True,cells=cells,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 checks.append(f'{id}: dimensions, nonempty cells, alpha and >=8% margin PASS')
bg0=Image.open('/workspace/animal-farm-1105/backgrounds/BG-FARM-DAY.png').convert('RGBA')
for i in (1,2):
 p=R/'sheets'/f'S-BG-LV_{i}.png';im=Image.open(p).convert('RGBA');assert im.size==(1170,2532);assert im.getchannel('A').getextrema()==(255,255)
 safe=(0,963,1170,1671);assert not ImageChops.difference(im.crop(safe),bg0.crop(safe)).getbbox()
 manifest.append(dict(id=p.stem,file=f'sheets/{p.name}',width=1170,height=2532,transparent=False,safe_zone_y=[.38,.66],sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 checks.append(f'{p.stem}: size, opaque and original central lawn unchanged PASS')
(R/'docs'/'atlas-map.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
checks.append('Browser preview: 15 images loaded, 10 sprite previews, frame changes verified, 0 JS errors (Chromium)')
(R/'docs'/'verification.txt').write_text('\n'.join(checks)+'\n')
readme='''# 동물 농장 2차 리소스 · 1106

짧은 팔다리·큰 머리·둥근 몸통으로 수정한 아기 동물 버전입니다.

필수 13종, PNG 15장. 선택 항목인 계절 배경은 포함하지 않습니다.

- `sheets/`: 앱에 사용하는 완성 PNG 시트. 배경 외 투명, 각 칸 여백 최소 8%.
- `preview.html`: 압축 해제 후 PC 브라우저에서 열어 전체 시트와 걷기·위젯 재생 확인.
- `docs/atlas-map.json`: 칸별 ID, 좌표, 크기, 파일 SHA-256.
- `source/`: 소형 리소스 SVG 원본 및 제작 스크립트. 생성 원본 이미지는 패키지 용량 때문에 제외.

동물 순서: A1 레서판다 / A2 카피바라 / A3 양 / A4 하늘다람쥐 / A5 아기판다.
가로 시트는 왼쪽부터 위 순서, 걷기와 위젯은 위에서 아래 동물 순서입니다.

걷기: 512×512, 3열×5행. 왼발→모음→오른발→모음, 프레임당 180ms 권장.
위젯: 512×512, 3열×5행. 기본→숨쉬기→눈감음. 900/900/160ms 권장.
합류 효과는 `S-ARRIVE_2.png`이며 캐릭터 위에 별도 레이어로 사용합니다.
S-LOCKED 중앙 밝은 원은 앱의 물음표를 얹는 자리입니다.
S-EMOTE 느낌표·물음표·음표는 요청된 아이콘 도형이며 문자 레이어가 없습니다.
성장 배경은 1차 BG-FARM-DAY 원본 구도를 유지합니다. 동물 배치 영역 y=38~66%는 원본과 동일합니다.
배경 레벨 1은 밭·우물·연못, 레벨 2는 풍차·사과나무집·온천을 추가했습니다.

PNG 가장자리의 투명 픽셀 RGB는 사용하지 말고 알파 채널과 함께 렌더링하세요.
모든 좌표는 원본 해상도 기준이며 셀 사이 별도의 gutter는 없습니다.
'''
(R/'README.md').write_text(readme)
cards=''.join(f'<section><h2>{m["id"]}</h2><p>{m["width"]} × {m["height"]}</p><a href="{m["file"]}" download>PNG 저장</a><div class="board"><img src="{m["file"]}"></div></section>' for m in manifest)
anims=''.join(f'<div><b>A{i+1}</b><div class="sprite" data-kind="{kind}" data-row="{i}" style="background-image:url(sheets/{kind}.png);background-position:0 {-i*160}px"></div></div>' for kind in ['S-WALK','S-WIDGET-ANI'] for i in range(5))
(R/'preview.html').write_text('''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>동물 농장 2차 리소스</title><style>body{font:15px system-ui;background:#f7f3e9;color:#594334;margin:32px auto;max-width:1100px;padding:0 20px}h1{font-size:28px}section{background:white;border-radius:20px;padding:20px;margin:20px 0;overflow:hidden}h2{font-size:18px}.board{margin-top:16px;background:repeating-conic-gradient(#f6f4ee 0 25%,#e9e6df 0 50%) 0/24px 24px}.board img{display:block;max-width:100%;max-height:650px;margin:auto}a{color:#607e5b}.animations{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px}.sprite{width:160px;height:160px;background-size:480px 800px}</style><h1>동물 농장 · 2차 리소스</h1><p>필수 13종 / PNG 15장 · 아래 애니메이션은 실제 시트 프레임을 재생합니다.</p><div class="animations">'''+anims+'</div>'+cards+'''<script>const start=performance.now();function draw(t){document.querySelectorAll('.sprite').forEach(e=>{let f;if(e.dataset.kind==='S-WALK')f=[0,1,2,1][Math.floor((t-start)/180)%4];else{let n=(t-start)%1960;f=n<900?0:n<1800?1:2}e.style.backgroundPosition=`${-f*160}px ${-Number(e.dataset.row)*160}px`});requestAnimationFrame(draw)}requestAnimationFrame(draw)</script></html>''')
out=Path('/workspace/downloads/animal-farm_2차_1106.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,6) as z:
 for p in sorted(R.rglob('*')):
  if p.is_file() and p.relative_to(R).parts[0] not in ('cells','previews') and p.name!='inputs.json':z.write(p,Path('animal-farm_2차_1106')/p.relative_to(R))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(out),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),png_count=len(manifest)),ensure_ascii=False))

우선 적용 리소스: 동물 5종의 idle/happy/full 15컷 + 낮 배경 1장.
전체 세트는 animal-farm-resources-1105.zip에 있습니다.

# 동물 농장 · 리소스 1105

요청서 기준 필수 PNG 78개입니다. 캐릭터·아이콘은 배경 투명이며, 글자·숫자·실제 브랜드를 넣지 않았습니다.

1. ZIP 전체를 압축 해제합니다.
2. `preview.html`을 PC 브라우저로 열면 그림과 위젯 프레임을 볼 수 있습니다.
3. 각 폴더의 PNG를 바로 복사해 사용하세요.
4. `docs/asset-manifest.json`에 ID, 파일 경로, 크기, 여백, SHA-256이 있습니다.

| 폴더 | 개수 | 규격 |
|---|---:|---|
| characters | 35 | 1024×1024, 5동물×7포즈 |
| backgrounds | 2 | 1170×2532, 낮·밤 |
| icons | 14 | 256×256, 탭 선택·비선택 포함 |
| system | 2 | 96×96, 단색 흰색 실루엣 |
| banners | 2 | 1074×168 |
| effects | 5 | 코인3, 하트1, 레벨업1 |
| widgets | 10 | 배경2, 움직임 프레임8 |
| categories | 7 | 720×720, 브랜드 없는 카테고리 |
| app | 1 | APP-ICON 1024×1024 |

캐릭터 이름: A1_redpanda / A2_capybara / A3_sheep / A4_flyingsquirrel / A5_babypanda. 포즈: idle, work, full, happy, heart, sleep, hello.

탭 상태는 `I-TAB-HOME_selected`, `I-TAB-HOME_unselected`, `I-TAB-SHOP_selected`, `I-TAB-SHOP_unselected`입니다. 코인 효과는 `FX-COIN_small`, `FX-COIN_medium`, `FX-COIN_sparkle`입니다.

v29 원본 HTML·슬롯 표시 캡처는 이번 첨부에 포함되지 않아 원본 앱에 직접 적용하지 않았습니다. 문서에 지정된 ID와 픽셀 규격으로 제작했습니다. 픽셀 크기가 없는 위젯 배경은 2:2 = 512×512, 4:2 = 1024×512로 정했습니다. 선택 항목 LV2/LV3 배경은 제외했습니다.

`previews/`는 검토용 합성 시트입니다. 이 시트에만 ID 라벨·안전 영역 안내가 있으며 실제 PNG에는 없습니다. 수정 가능한 아이콘·카테고리·효과 SVG는 `source/`에 있습니다.
